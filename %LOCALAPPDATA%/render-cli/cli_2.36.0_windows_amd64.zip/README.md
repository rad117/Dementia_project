# Render CLI

## Installation

- [Homebrew](https://render.com/docs/cli#homebrew-macos-linux)
- [Direct Download](https://render.com/docs/cli#direct-download)

## Documentation

Documentation is hosted at https://render.com/docs/cli.

## Contributing

To create a new command, use the `cmd/template.go` template file as a starting point. Reference the [CLI Style Guide](docs/STYLE.md) to learn more about command naming, flags, arguments, and help text conventions.

### Dev setup

We use [prek](https://prek.j178.dev/) to run precommit-compatible checks locally and in CI.

- If you didn't install `prek` following the [dev setup guide](https://slab.render.com/posts/dev-setup-guide-ect5drdb), do so now (e.g., `brew install prek`)
- Set up prek git hooks with `prek install`.

Run the shell test suite with `bashunit_tests/run.sh`. The runner downloads the
pinned BashUnit release on first use.

Read [AGENTS.md](AGENTS.md) for common dev commands. It's written for humans too!

### Regenerate workflow callback bindings

Set `RENDER_API_PATH` to your local Render API checkout. From the CLI repository root, run:

```sh
export RENDER_API_PATH=/path/to/api
cd pkg/workflows/taskserver
go run github.com/oapi-codegen/oapi-codegen/v2/cmd/oapi-codegen@v2.4.1 \
  -config=oapi-generate.yaml "$RENDER_API_PATH/pkg/durableworkflow/callbackapi/openapi.yaml"
```

This updates `pkg/workflows/taskserver/api_gen.go` from the callback API schema.
